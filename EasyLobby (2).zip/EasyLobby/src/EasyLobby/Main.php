<?php

namespace EasyLobby;

use pocketmine\plugin\PluginBase;
use EasyLobby\EventListener;
use FormAPI\FormAPI;

class Main extends PluginBase{
    public static $main;
    public function onEnable()
    {
        self::$main = $this;
        $this->getLogger()->info("-Das plugin ist an!-");
        $this->getServer()->getPluginManager()->registerEvents(new EventListener($this),$this);
        $this->getConfig()->save();
        FormAPI::enable($this);
    }
    public function getMain(): self{
        return self::$main;
}
}