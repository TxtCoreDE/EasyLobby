<?php

namespace EasyLobby;

use EasyLobby\Main;
use pocketmine\entity\Effect;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\Player;
use FormAPI\FormAPI;
use pocketmine\level\Level;
use pocketmine\Server;
use function MongoDB\BSON\toRelaxedExtendedJSON;
use pocketmine\entity\Entity;


class EventListener implements Listener{


    public function onJoin(PlayerJoinEvent $event)
    {
        $player = $event->getPlayer();
        $name = $player->getDisplayName();
        $player->getInventory()->clearAll();
        $player->setXpLevel(2020);
        $event->setJoinMessage("  §6+§R[$name]");
        $player->getInventory()->setItem(1, Item::get(57, 0, 1)->setCustomName("§c Partikel"));
        $player->getInventory()->setItem(5, Item::get(399, 0, 1)->setCustomName("§e Navigator"));
        $player->getInventory()->setItem(7, Item::get(130, 0, 1)->setCustomName("§2 Gadgets"));
        $player->getInventory()->setItem(4, Item::get(397,3,1)->setCustomName("§3 Profil"));


        }


    public function onInteract(PlayerInteractEvent $event)
    {
        $item = $event->getItem();
        $player = $event->getPlayer();
        if ($item->getCustomName() === "§c Partikel") {
            $this->onPerksUI($player);
        }
        if ($item->getCustomName() === "§e Navigator") {
            $this->onNavigatorUI($player);
        }
        if ($item->getCustomName() === "§2 Gadgets") {
            $this->onGadgetUI($player);
        }
        if($item->getCustomName() === "§3 Profil"){
            $this->onProfilUI($player);
        }
    }

    public function onGadgetUI($player)
    {
        $api = FormAPI::getInstance();
        $form = $api->createSimpleForm(function (Player $player, int $data = null) {


            if($data === null){
                return true;
            }
            switch ($data) {
                case 0:
                    $this->onSizeUI($player);
                    break;
                case 1:
                   $this->onFlyUI($player);
                    break;
            }

        });
        $form->setTitle("§6A§eL §r| Gadgt Menü");
        $form->setContent("");
        $form->addButton("§aSize");
        $form->addButton("§eFly");
        $form->sendToPlayer($player);

    }

    public function onFlyUI($player){
        $api = FormAPI::getInstance();
        $form = $api->createSimpleForm(function (Player $player, int $data = null){
            if($data === null){
                return true;
            }
            switch ($data){
                case 0:
                    $player->sendMessage("§6Altags§eLeben §r > Fly is enabling!");
                    $player->setFlying(true);
                    $player->setAllowFlight(true);
                    break;
                case 1:
                    $player->sendMessage("§6Altags§eLebem §r | Fly is disnabling!");
                    $player->setFlying(false);
                    $player->setAllowFlight(false);
                    break;
            }
        });
        $form->setTitle("§6A§eL §r| Fly Menü");
        $form->setContent("");
        $form->addButton("§a On");
        $form->addButton("§c Off");
        $form->sendToPlayer($player);

    }



    public function onSizeUI($player)
    {
        $api = FormAPI::getInstance();
        $form = $api->createSimpleForm(function (Player $player, int $data = null) {

            if($data === null){
                
                return true;
            }
            switch ($data) {
                case 0:
                    $player->setScale(0.3);
                    $player->sendMessage("§6Altags§eLeben§r| You´re Size are Mouse!");
                    break;
                case 1:
                    $player->setScale(0.7);
                    $player->sendMessage("§6Altags§eLeben§r| You´re Size are Smal!");
                    break;
                case 2:
                    $player->setScale(2);
                    $player->sendMessage("§6Altags§eLeben§r| You´re Size are Big!");
                    break;
                case 3:
                    $player->setScale(3);
                    $player->sendMessage("§6Altags§eLeben §r| You´re Size are Very Big");
                    break;
                case 4:
                    $player->setScale(1);
                    $player->sendMessage("§6Altags§eLeben §r| You´re has you Size Reset!");
                    break;
            }

        });
        $form->setTitle("§6A§eL §r| Size Menü");
        $form->setContent("");
        $form->addButton("§5 Mouse");
        $form->addButton("§5 Smal");
        $form->addButton("§5 Big");
        $form->addButton("§5 Verry Big");
        $form->addButton("§5 Reset");
        $form->sendToPlayer($player);
    }

    public function onNavigatorUI($player)
    {
        $api = FormAPI::getInstance();
        $form = $api->createSimpleForm(function (Player $player, int $data = null) {

            if($data === null){
                return true;
            }
            switch ($data) {
                case 0:
                    $player->teleport(new Vector3(0, 0, 0));
                    $player->addTitle("§eAltags§eLeben §r\n §4CityBuild");
                break;
                case 1:
                  $player->sendMessage("§6Altags§eLeben §r > Coming");
                    break;
            }

        });
        $form->setTitle("§6A§eL §r| Teleport Menü");
        $form->setContent("");
        $form->addButton("§6CityBuild \n Stats§r: §aOnline");
        $form->addButton("§cComing...");
        $form->sendToPlayer($player);

    }
    public function onPerksUI($player){
        $api = FormAPI::getInstance();
        $form = $api->createSimpleForm(function (Player $player, int $data = null) {
        if($data === null){
            return true;
        }
        switch($data) {
            case 0:
                $player->sendMessage("§6AltagsLeben §r| This function is being revised!");
                break;
            case 1:
                  $player->sendMessage("§6Altags§eleben §r| You are to Back!");
                break;
        }
        });
        $form->setTitle("§6A§eL §r|Particle Menü");
        $form->setContent("This function is in the BETA");
        $form->addButton("§3 Diamond Particle");
        $form->addButton("§cBack");
        $form->sendToPlayer($player);
    }


    public function onPlace(BlockPlaceEvent $event)
    {

            $event->setCancelled(true);
        }


    public function onBreak(BlockBreakEvent $event)
    {

            $event->setCancelled(true);
        }


    public function onDrop(PlayerDropItemEvent $event)
    {
            $event->setCancelled(true);


    }

    public function onMove(PlayerMoveEvent $event)
    {
        $player = $event->getPlayer();
        $player->setFood(20);
        $player->setHealth(20);
    }
    public function onQuit(PlayerQuitEvent $event){
        $name = $event->getPlayer()->getDisplayName();
        $event->setQuitMessage("§e[-$name §e]");
    }
    public function onProfilUI($player){
        $api = FormAPI::getInstance();
        $form = $api->createSimpleForm(function (Player $player, int $data = null) {
            if($data === null){
                return true;
            }
            switch ($data){
                case 0:
                    $player->sendMessage("§6AltagsLeben §r| You have successfully set your language to English!");
                    break;
                case 1:
                  $player->sendMessage("§6AltagsLeben §r| Du hast die Sprache auf Deutsch gestzt! \n Rejoinen um auf die german lobby\n Zu kommen!");
                    break;
         }
        });
        $form->setTitle("§6A§eL §r| Profil");
        $form->setContent("Setting you lounge!");
        $form->addButton("§3 English");
        $form->addButton("§3 German");
        $form->sendToPlayer($player);
    }

}